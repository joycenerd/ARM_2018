#include <stdio.h>


int main()
{
    // two arguments (80,48) will be passed into gcd function
	int the_gcd=gcd(80,48);
    // print gcd result
	printf("The greatest common divider is %d\n",the_gcd);
	return 0;
}
